package Book.values;

/*import java.io.IOException;

import com.fasterxml.jackson.databind.JsonNode;

public class Items {

	JsonNode js;

	public Items(JsonNode json) {
		
		this.js = json;
	}

	public JsonNode itemsData() throws IOException {

		JsonNode items = js.get("items");
		return items;

	}

}*/
